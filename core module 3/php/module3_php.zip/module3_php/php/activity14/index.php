<?php
$n=5;
// A for loop
for($i=1; $i<=$n; $i++)
{
//Declaring a for loop inside in the another for loop
// A nester for loop for($j=1; $j<=$i; $j++)
{
echo ' * ';
}
echo nl2br("\n");
}
// A for loop for($i=$n; $i>=1; $i--)
{
//Declaring a for loop inside in the another for loop
// A nester for loop for($j=1; $j<=$i; $j++)
{
echo ' * ';
}
echo nl2br("\n ");
}
?>
 
