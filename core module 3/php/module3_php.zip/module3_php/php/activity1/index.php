<html>
<body>
<form action="6 form.php" method="post">
First Name: <input type="text" name="name"><br><br> Last Name: <input type="text" name="lname"><br><br>
<input type="submit">
</form>
</body>
</html>
<html>
<body>
Welcome <?php echo $_POST["name"]." "; ?>
<?php echo $_POST["lname"]; ?>
</body>
</html>
 
