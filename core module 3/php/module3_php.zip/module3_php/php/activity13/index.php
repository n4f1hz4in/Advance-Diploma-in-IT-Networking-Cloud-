<?php
// Declaring a variable whose factorial is to be find
$n = 6;
$x = 1;
//Calculating the factorial of a given number for($i=1;$i<=$n-1;$i++)
{
$x*=($i+1);
}
// Displaying the factorial of a given number echo "The factorial of $n = $x"."\n";
?>
