<?php phpinfo();
?>
