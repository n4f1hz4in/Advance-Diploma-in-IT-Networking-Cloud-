<?php
function primeCheck($number){ //creating a function primeCheck
 if ($number == 1)
return 0;
for ($i = 2; $i <= $number/2; $i++){ if ($number % $i == 0)
return 0; }
return 1;
}
$number = 31;	//input number 31
$flag = primeCheck($number);	//checking prime or not
 if ($flag == 1)
echo "$number is Prime"; else
echo "$number is Not Prime"
?>
