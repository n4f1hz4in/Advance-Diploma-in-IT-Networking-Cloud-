<?php
 function trinary_Test($n){
$r = $n > 30
? nl2br("greater than 30 \n")
: ($n > 20
? nl2br("greater than 20 \n")
: ($n >10
? nl2br("greater than 10 \n")
: "Input a number atleast greater than 10!")); echo $n." : ".$r."\n";
}
trinary_Test(32);
 trinary_Test(21); trinary_Test(12);
 trinary_Test(4);
?>

