<?php
echo strtolower("Hello WORLD.<br>"); echo strtoupper("Hello WORLD!<br>"); echo "Php Strings."."\n";
echo "This is a bad command : del c:\\*.*"."\n"; echo lcfirst("Hello world!<br>");
$str = "Hello"; echo md5($str);
$arr = array('Hello','World!','Beautiful','Day!'); echo join(" ",$arr);
?>
