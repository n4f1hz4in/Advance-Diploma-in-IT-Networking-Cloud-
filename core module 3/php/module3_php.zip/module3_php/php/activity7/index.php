<?php
// nl2br is used for newlines.
 echo nl2br("Hi NSTI \n"); 
echo nl2br("Hi NSTI \n");
$file = basename($_SERVER['PHP_SELF']);
$no_of_lines = count(file($file));
echo "There are $no_of_lines lines in $file"."\n";
?>
xvxzsav
dsd