<?php
$a=100;
$b=50;
$c=20;
echo "<table border=1 cellspacing=0 cellpading=0>
<!— column which spans 2 -->
<tr> <th colspan= 2> Marks Sheet </th></tr>
<tr> <td><font color=blue>Marks of Mr. A is</td>
<td>$a</font></td></tr>
<tr> <td><font color=blue>Marks of Mr. B is</td>
<td>$b</font></td></tr>
<tr> <td><font color=blue>Marks of Mr. C is</td>
<td>$c</font></td></tr>
</table>";
?>
